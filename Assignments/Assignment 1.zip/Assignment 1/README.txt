

please run the Assignment_1.ipynb (or Assignment_1.py) for answers


--
Additional files
1. get_graph.py: 		constructs adjacency matrix from the given input file
2. compute_metrics.py: 	computes all the metrics required in the answers
3. output.tx: 			solution to all questions in the required format
